import matplotlib.pyplot as plt

first = [20.032, 20.096, 20.032, 20.032, 20.032]
second = [20.064, 20.000, 19.968, 19.936, 20.000]
third = [19.968, 20.160, 20.160, 20.096, 19.904]

x = [1, 2, 4, 8, 16]

# Plot lines with different marker sizes
plt.plot(x, first, label = '100, 100, 0.001',  marker='s', ms=5, linewidth=1, color='darkorange') # square
plt.plot(x, second, label = '10, 10, 0.001',  marker='^', ms=5, linewidth=1, color='royalblue') # triangle
plt.plot(x, third, label = '100, 100, 0.01',  marker='+', ms=10, linewidth=1, color='#222222') # circle

plt.ylabel('Average Execution Time',fontsize=12)

plt.xlabel('Thread Count',fontsize=12)
plt.yticks(fontsize=11)

plt.xticks([1, 2, 4, 8, 16], fontsize=12)
plt.legend(fontsize=10, title='m, n, tol', loc='upper left')
plt.show()